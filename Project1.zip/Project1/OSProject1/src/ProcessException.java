public class ProcessException extends Exception {
	public ProcessException(String message){
		//add information
	}
	public ProcessException(String message, Throwable throwable){
		
	}
}
